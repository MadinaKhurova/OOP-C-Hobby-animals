﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using Animals;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace testAnimal;

[TestClass]
public class UnitTest1
{
    [TestMethod]
    public void Assigning()
    {
        List<Animal> list1 = new List<Animal>();
        list1.Add(new Fish("Kim", 10));
        Assert.AreEqual("Kim", list1[0].Name);
        Assert.AreEqual(10, list1[0].GetLvl());

    }
    [TestMethod]
    public void ModifyingLevel()
    {
        Fish flippy = new Fish("Jin", 10);
        Good goodMood = Good.Instance();

        
        goodMood.ChangeF(flippy);

        
        Assert.AreEqual(11, flippy.GetLvl());

        Bird owl = new Bird("Openheimer", 10);
        Bad badMood = Bad.Instance();
    }
    [TestMethod]
    public void ModifyingList()
    {
        List<Animal> lists = new List<Animal>
        {
            new Bird("Natuto", 10),
            new Bird("Sasuke", 20),
            new Bird("Sakura",100)
        };
        Bad badMood = Bad.Instance();
        foreach(Bird l in lists)
        {
            badMood.ChangeB(l);
        }
        List<Animal> listsres = new List<Animal>
        {
            new Bird("Natuto", 7),
            new Bird("Sasuke", 17),
            new Bird("Sakura",97)
        };
        
        Assert.AreEqual(lists[0].GetLvl(), listsres[0].GetLvl());
        Assert.AreEqual(lists[1].GetLvl(), listsres[1].GetLvl());
        Assert.AreEqual(lists[2].GetLvl(), listsres[2].GetLvl());

    }
    [TestMethod]
    public void TestMinMethod()
    {
        List<Animal> lists = new List<Animal>();
        Assert.AreEqual(0, lists.Count);
        lists.Add(new Dog("Geto", 3));
        Assert.AreEqual(1, lists.Count);
        

    }

}
