﻿using TextFile;
namespace Animals;

class Program
{
    
    static void Main(string[] args)
    {
        TextFileReader reader = new("inp.txt");
        reader.ReadLine(out string line); int n = int.Parse(line);
        List<Animal> animals = new();
        for(int i = 0; i<n; ++i)
        {
            char[] separators = new char[] { ' ', '\t' };
            Animal animal = null;
            if(reader.ReadLine(out line))
            {
                string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                char ch = char.Parse(tokens[0]);
                string name = tokens[1];
                int p = int.Parse(tokens[2]);

                switch (ch)
                {
                    case 'F': animal = new Fish(name, p); break;
                    case 'D': animal = new Dog(name, p); break;
                    case 'B': animal = new Bird(name, p); break;
                }

            }
            animals.Add(animal);
        }
        
        List<IMood> track = new();
        reader.ReadLine(out string line2);
        foreach (char m in line2)
        {
            switch (m)
            {
                case 'g': track.Add(Good.Instance()); break;
                case 'o': track.Add(Ordinary.Instance()); break;
                case 'b': track.Add(Bad.Instance()); break;
            }
            
        }


        try
        {
            int min = animals[0].GetLvl();
            string minName = animals[0].Name;
            for (int i = 0; i < n; ++i)
            {
                animals[i].Race(ref track);
                if (animals[i].Alive() && min > animals[i].GetLvl())
                {
                    min = animals[i].GetLvl();
                    minName = animals[i].Name;
                }
            }
            Console.WriteLine(minName);

        }
        catch (Exception e)
        {
            Console.WriteLine("{0}", e.ToString());
        }
       
    }
}

