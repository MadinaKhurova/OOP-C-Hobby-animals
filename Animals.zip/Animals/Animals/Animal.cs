﻿using System;
namespace Animals
{
	public abstract class Animal
	{
		public string Name { get; }
		protected int level;
        public void ModifyLevel(int e) { level += e; }
        public bool Alive() { return level > 0; }
        public int GetLvl() { return level; }
		protected Animal(string str, int e =0)
		{
			Name = str;
			level = e;
		}
        public void Race(ref List<IMood> track)
        {
            for (int j = 0; Alive() && j < track.Count; ++j)
            {
                track[j] = Traverse(track[j]);
            }
        }
        protected abstract IMood Traverse(IMood mood);
    }
	//fish
	 public class Fish : Animal
	{
		public Fish(string str, int e = 0) : base(str,e) { }
        protected override IMood Traverse(IMood mood)
        {
            return mood.ChangeF(this);
        }

    }

	//bird
	public class Bird : Animal
	{
        public Bird(string str, int e = 0) : base(str, e) { }
        protected override IMood Traverse(IMood mood)
        {
            return mood.ChangeB(this);
        }
    }
    //dog
    public class Dog : Animal
    {
        public Dog(string str, int e = 0) : base(str, e) { }
        protected override IMood Traverse(IMood mood)
        {
            return mood.ChangeD(this);
        }
    }

}

