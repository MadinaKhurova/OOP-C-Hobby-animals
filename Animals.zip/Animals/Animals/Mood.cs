﻿using System;
namespace Animals
{
	public interface IMood
	{
		IMood ChangeF(Fish p);
		IMood ChangeD(Dog p);
	    IMood ChangeB(Bird p);
	}
	public class Good : IMood
	{
		public IMood ChangeF(Fish p)
		{
			p.ModifyLevel(1);
			return this;
		}
        public IMood ChangeD(Dog p)
        {
            p.ModifyLevel(3);
            return this;
        }
        public IMood ChangeB(Bird p)
        {
            p.ModifyLevel(2);
            return this;
        }
		private Good() { }
		private static Good instance = null;
		public static Good Instance()
		{
			if(instance == null)
			{
				instance = new Good();
			}
			return instance;
		}
    }
    //ordinary
    public class Ordinary : IMood
    {
        public IMood ChangeF(Fish p)
        {
            p.ModifyLevel(-3);
            return this;
        }
        public IMood ChangeD(Dog p)
        {
            p.ModifyLevel(0);
            return this;
        }
        public IMood ChangeB(Bird p)
        {
            p.ModifyLevel(1);
            return this;
        }
        private Ordinary() { }
        private static Ordinary instance = null;
        public static Ordinary Instance()
        {
            if (instance == null)
            {
                instance = new Ordinary();
            }
            return instance;
        }
    }
    public class Bad : IMood
    {
        public IMood ChangeF(Fish p)
        {
            p.ModifyLevel(-5);
            return this;
        }
        public IMood ChangeD(Dog p)
        {
            p.ModifyLevel(-10);
            return this;
        }
        public IMood ChangeB(Bird p)
        {
            p.ModifyLevel(-3);
            return this;
        }
        private Bad() { }
        private static Bad instance = null;
        public static Bad Instance()
        {
            if (instance == null)
            {
                instance = new Bad();
            }
            return instance;
        }
    }
}

